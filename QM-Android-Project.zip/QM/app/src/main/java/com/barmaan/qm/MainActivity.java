package com.barmaan.qm;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity {
    private final Random random = new Random();
    private TextView questionText, scoreText, feedbackText;
    private Button[] answers = new Button[4];
    private int correctAnswer, score = 0, questionNumber = 0;
    private boolean answered = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);
        feedbackText = findViewById(R.id.feedbackText);

        answers[0] = findViewById(R.id.answer1);
        answers[1] = findViewById(R.id.answer2);
        answers[2] = findViewById(R.id.answer3);
        answers[3] = findViewById(R.id.answer4);

        for (int i = 0; i < answers.length; i++) {
            final int index = i;
            answers[i].setOnClickListener(v -> chooseAnswer(index));
        }

        Button next = findViewById(R.id.nextButton);
        next.setOnClickListener(v -> nextQuestion());

        nextQuestion();
    }

    private void nextQuestion() {
        answered = false;
        questionNumber++;
        feedbackText.setText("");
        scoreText.setText("Score: " + score + "   |   Question: " + questionNumber);

        int a = random.nextInt(20) + 1;
        int b = random.nextInt(20) + 1;
        int op = random.nextInt(4);
        String symbol;

        switch (op) {
            case 0:
                symbol = "+";
                correctAnswer = a + b;
                break;
            case 1:
                if (b > a) {
                    int temp = a;
                    a = b;
                    b = temp;
                }
                symbol = "−";
                correctAnswer = a - b;
                break;
            case 2:
                a = random.nextInt(12) + 1;
                b = random.nextInt(12) + 1;
                symbol = "×";
                correctAnswer = a * b;
                break;
            default:
                b = random.nextInt(12) + 1;
                correctAnswer = random.nextInt(12) + 1;
                a = b * correctAnswer;
                symbol = "÷";
                break;
        }

        questionText.setText(a + " " + symbol + " " + b + " = ?");
        int correctSlot = random.nextInt(4);
        int[] values = new int[4];
        values[correctSlot] = correctAnswer;

        for (int i = 0; i < 4; i++) {
            if (i == correctSlot) continue;

            int candidate;
            boolean duplicate;
            do {
                candidate = correctAnswer + random.nextInt(19) - 9;
                if (candidate < 0) candidate = random.nextInt(20);

                duplicate = candidate == correctAnswer;
                for (int j = 0; j < 4; j++) {
                    if (j != correctSlot && j < i &&
                        values[j] == candidate) {
                        duplicate = true;
                    }
                }
            } while (duplicate);

            values[i] = candidate;
        }

        for (int i = 0; i < 4; i++) {
            answers[i].setText(String.valueOf(values[i]));
            answers[i].setTag(values[i]);
            answers[i].setEnabled(true);
        }
    }

    private void chooseAnswer(int index) {
        if (answered) return;
        answered = true;

        int selected = (Integer) answers[index].getTag();

        if (selected == correctAnswer) {
            score++;
            feedbackText.setText("Correct! Great job!");
            feedbackText.setTextColor(Color.rgb(20, 145, 70));
        } else {
            feedbackText.setText("Correct answer: " + correctAnswer);
            feedbackText.setTextColor(Color.rgb(195, 45, 55));
        }

        scoreText.setText("Score: " + score + "   |   Question: " + questionNumber);

        for (Button button : answers) {
            button.setEnabled(false);
        }
    }
}
